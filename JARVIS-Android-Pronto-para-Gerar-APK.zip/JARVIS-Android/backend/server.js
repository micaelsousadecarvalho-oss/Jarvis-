import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const SYSTEM_PROMPT = `Você é JARVIS, assistente pessoal inteligente inspirado em um mordomo tecnológico.
Fale em português brasileiro, com elegância, calma, eficiência e humor discreto.
Chame a pessoa de senhor quando soar natural. Seja claro, honesto e objetivo.
Explique assuntos complexos de forma simples. Não invente informações nem afirme ter executado ações que não executou.
Peça confirmação antes de ações importantes.`;

app.get("/health", (_req, res) => res.json({ ok: true, service: "JARVIS backend" }));

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Mensagem vazia." });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "Configure OPENAI_API_KEY no backend." });

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-6-astra",
        instructions: SYSTEM_PROMPT,
        input: message
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "Falha na API de IA." });
    const reply = data.output_text || (data.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text).join("\n");
    res.json({ reply: reply || "Senhor, não recebi uma resposta em texto." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Erro interno." });
  }
});

app.post("/api/tts", async (req, res) => {
  try {
    const text = String(req.body?.text || "").trim();
    if (!text) return res.status(400).json({ error: "Texto vazio." });
    if (!process.env.FISH_API_KEY) return res.status(503).json({ error: "Configure FISH_API_KEY no backend." });

    const response = await fetch("https://api.fish.audio/v1/tts", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.FISH_API_KEY}`,
        "Content-Type": "application/json",
        "model": "s2.1-pro-free"
      },
      body: JSON.stringify({ text, format: "mp3" })
    });
    if (!response.ok) {
      const errorText = await response.text();
      return res.status(response.status).json({ error: errorText || "Falha no Fish Audio." });
    }
    const audio = Buffer.from(await response.arrayBuffer()).toString("base64");
    res.json({ audio, format: "mp3" });
  } catch (err) {
    res.status(500).json({ error: err.message || "Erro interno no TTS." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`JARVIS backend ativo na porta ${port}`));
