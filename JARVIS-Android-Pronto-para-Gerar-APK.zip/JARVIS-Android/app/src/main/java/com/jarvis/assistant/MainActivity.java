package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    // Ajuste para o endereço HTTPS do backend publicado.
    private static final String SERVER_URL = "http://10.0.2.2:3000";
    private static final String SPOTIFY_TRACK_URI = "spotify:track:39shmbIHICJ2Wxnk1fPSdz";
    private static final String SPOTIFY_TRACK_WEB = "https://open.spotify.com/track/39shmbIHICJ2Wxnk1fPSdz";
    private static final String WAKE_PHRASE_HELP = "Diga: Olá, bebê, papai chegou!";
    private static final int MIC_PERMISSION = 41;

    private LinearLayout messages;
    private TextView status;
    private EditText input;
    private Button micButton;
    private SpeechRecognizer speechRecognizer;
    private MediaPlayer player;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean listening = false;
    private boolean openingSpotify = false;
    private long lastMusicTrigger = 0;
    private final int cyan = Color.rgb(0, 220, 255);
    private final int bg = Color.rgb(5, 12, 25);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildInterface();
        addMessage("JARVIS", "JARVIS inicializado. Comando de música preparado. " + WAKE_PHRASE_HELP, false);
        setupSpeech();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startWakeListening();
        } else {
            status.setText("PERMISSÃO DE MICROFONE NECESSÁRIA");
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION);
        }
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(18));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density); }

    private void buildInterface() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(14));
        page.setBackgroundColor(bg);
        setContentView(page);

        TextView brand = new TextView(this);
        brand.setText("J.A.R.V.I.S");
        brand.setTextColor(cyan); brand.setTextSize(29);
        brand.setTypeface(Typeface.create("sans-serif-light", Typeface.BOLD));
        brand.setGravity(Gravity.CENTER);
        page.addView(brand, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView subtitle = new TextView(this);
        subtitle.setText("JUST A RATHER VERY INTELLIGENT SYSTEM");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(9);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle);

        TextView orb = new TextView(this);
        orb.setText("◉"); orb.setTextSize(62); orb.setTextColor(cyan);
        orb.setGravity(Gravity.CENTER);
        orb.setBackground(shape(Color.rgb(8, 27, 45), cyan));
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(dp(112), dp(112));
        op.gravity = Gravity.CENTER; op.topMargin = dp(14); op.bottomMargin = dp(8);
        page.addView(orb, op);

        status = new TextView(this);
        status.setText("INICIALIZANDO...");
        status.setTextColor(cyan); status.setTextSize(11);
        status.setGravity(Gravity.CENTER);
        page.addView(status);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(12), 0, dp(12));
        scroll.addView(messages);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.topMargin = dp(10); sp.bottomMargin = dp(10);
        page.addView(scroll, sp);

        input = new EditText(this);
        input.setSingleLine(false); input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY); input.setHint("Digite uma instrução...");
        input.setPadding(dp(14), dp(10), dp(14), dp(10));
        input.setBackground(shape(Color.rgb(13, 25, 43), cyan));
        page.addView(input, new LinearLayout.LayoutParams(-1, dp(52)));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(0, dp(10), 0, 0);
        Button send = new Button(this); send.setText("ENVIAR");
        micButton = new Button(this); micButton.setText("🎙 OUVIR");
        controls.addView(send, new LinearLayout.LayoutParams(0, dp(50), 1));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(50), 1);
        mp.leftMargin = dp(8); controls.addView(micButton, mp);
        page.addView(controls);

        send.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            if (!text.isEmpty()) { input.setText(""); sendMessage(text); }
        });
        micButton.setOnClickListener(v -> startWakeListening());
    }

    private void addMessage(String who, String text, boolean user) {
        TextView bubble = new TextView(this);
        bubble.setText((user ? "VOCÊ" : who) + "\n" + text);
        bubble.setTextColor(user ? Color.WHITE : Color.rgb(180, 245, 255));
        bubble.setTextSize(14); bubble.setPadding(dp(14), dp(11), dp(14), dp(11));
        bubble.setBackground(shape(user ? Color.rgb(18, 42, 62) : Color.rgb(9, 29, 44), user ? Color.rgb(50,110,145) : cyan));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(9);
        messages.addView(bubble, p);
    }

    private void sendMessage(String text) {
        addMessage("VOCÊ", text, true);
        status.setText("ANALISANDO INFORMAÇÕES...");
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject(); body.put("message", text);
                JSONObject result = postJson(SERVER_URL + "/api/chat", body);
                String answer = result.optString("reply", "Não consegui interpretar a resposta.");
                runOnUiThread(() -> {
                    addMessage("JARVIS", answer, false);
                    status.setText("SISTEMA OPERACIONAL");
                    speak(answer);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("FALHA DE CONEXÃO");
                    addMessage("JARVIS", "Não consegui acessar o servidor. Confira o endereço do backend. Detalhe: " + e.getMessage(), false);
                });
            }
        }).start();
    }

    private JSONObject postJson(String address, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(address).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(60000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        InputStream stream = code < 400 ? c.getInputStream() : c.getErrorStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = stream.read(buf)) > 0) out.write(buf, 0, n);
        stream.close(); c.disconnect();
        if (code >= 400) throw new IOException(out.toString("UTF-8"));
        return new JSONObject(out.toString("UTF-8"));
    }

    private void setupSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage("JARVIS", "O serviço de reconhecimento de voz não está disponível neste aparelho.", false);
            return;
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { status.setText("JARVIS OUVINDO..."); listening = true; }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float v) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { status.setText("PROCESSANDO VOZ..."); }
            public void onError(int e) {
                listening = false;
                if (!openingSpotify && hasMicPermission() && isResumed()) scheduleListening(900);
            }
            public void onResults(Bundle b) {
                listening = false;
                ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (results != null && !results.isEmpty()) {
                    String spoken = results.get(0);
                    if (isWakePhrase(spoken)) {
                        playConfiguredSpotifyTrack();
                        return;
                    }
                    // A escuta contínua fica ativa enquanto o JARVIS está aberto.
                    if (!spoken.trim().isEmpty()) sendMessage(spoken);
                }
                if (!openingSpotify && hasMicPermission() && isResumed()) scheduleListening(1000);
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle b) {}
        });
    }

    private boolean hasMicPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isResumed() { return resumed; }
    private boolean resumed = false;

    private String normalize(String s) {
        String n = Normalizer.normalize(s.toLowerCase(new Locale("pt", "BR")), Normalizer.Form.NFD);
        n = n.replaceAll("\\p{M}", "");
        return n.replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    private boolean isWakePhrase(String heard) {
        String n = normalize(heard);
        boolean greeting = n.contains("ola bebe papai chegou") || n.contains("ola bebe o papai chegou");
        boolean wake = n.contains("acorda bebe papai chegou") || n.contains("acorda bebe o papai chegou");
        // Também aceita pequenas variações comuns do reconhecimento automático.
        boolean shortVariant = n.contains("bebe papai chegou") && (n.startsWith("ola") || n.startsWith("acorda"));
        return greeting || wake || shortVariant;
    }

    private void startWakeListening() {
        if (!hasMicPermission()) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION);
            return;
        }
        if (speechRecognizer == null) {
            addMessage("JARVIS", "Reconhecimento de voz indisponível neste aparelho.", false);
            return;
        }
        if (listening || openingSpotify || !resumed) return;
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            speechRecognizer.startListening(i);
            listening = true;
        } catch (Exception e) {
            listening = false;
            scheduleListening(1500);
        }
    }

    private void scheduleListening(long delay) {
        handler.removeCallbacks(restartListening);
        handler.postDelayed(restartListening, delay);
    }
    private final Runnable restartListening = this::startWakeListening;

    private void playConfiguredSpotifyTrack() {
        long now = System.currentTimeMillis();
        if (now - lastMusicTrigger < 8000) return;
        lastMusicTrigger = now;
        openingSpotify = true;
        listening = false;
        status.setText("ABRINDO SPOTIFY...");
        addMessage("JARVIS", "Comando reconhecido. Abrindo Should I Stay or Should I Go, do The Clash, no Spotify.", false);
        try {
            Intent spotify = new Intent(Intent.ACTION_VIEW, Uri.parse(SPOTIFY_TRACK_URI));
            spotify.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(spotify);
        } catch (Exception e) {
            try {
                Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse(SPOTIFY_TRACK_WEB));
                startActivity(web);
            } catch (Exception ex) {
                openingSpotify = false;
                addMessage("JARVIS", "Não consegui abrir o Spotify. Instale o aplicativo Spotify e tente novamente.", false);
                status.setText("SISTEMA OPERACIONAL");
                scheduleListening(1000);
            }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        if (openingSpotify) {
            openingSpotify = false;
            scheduleListening(1200);
        } else if (hasMicPermission()) {
            scheduleListening(500);
        }
    }

    @Override protected void onPause() {
        resumed = false;
        handler.removeCallbacks(restartListening);
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (Exception ignored) {}
        }
        listening = false;
        super.onPause();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MIC_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            addMessage("JARVIS", "Permissão de microfone concedida. " + WAKE_PHRASE_HELP, false);
            scheduleListening(400);
        } else if (requestCode == MIC_PERMISSION) {
            addMessage("JARVIS", "Sem permissão do microfone, não consigo detectar a frase de ativação.", false);
            status.setText("MICROFONE BLOQUEADO");
        }
    }

    private void speak(String text) {
        status.setText("GERANDO RESPOSTA DE VOZ...");
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject(); body.put("text", text);
                JSONObject result = postJson(SERVER_URL + "/api/tts", body);
                byte[] audio = android.util.Base64.decode(result.getString("audio"), android.util.Base64.DEFAULT);
                File f = new File(getCacheDir(), "jarvis_reply.mp3");
                try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(audio); }
                runOnUiThread(() -> {
                    try {
                        if (player != null) player.release();
                        player = new MediaPlayer(); player.setDataSource(f.getAbsolutePath());
                        player.setOnPreparedListener(MediaPlayer::start);
                        player.setOnCompletionListener(p -> {
                            status.setText("SISTEMA OPERACIONAL");
                            if (resumed && hasMicPermission()) scheduleListening(500);
                        });
                        player.prepareAsync();
                    } catch (Exception e) { status.setText("TEXTO PRONTO • ÁUDIO INDISPONÍVEL"); }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("RESPOSTA EM TEXTO • TTS NÃO CONFIGURADO");
                    if (resumed && hasMicPermission()) scheduleListening(500);
                });
            }
        }).start();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (player != null) player.release();
        super.onDestroy();
    }
}
